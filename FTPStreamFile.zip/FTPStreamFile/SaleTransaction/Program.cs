﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data;
using System.Data.SqlClient;
using System.Xml;
using System.IO;
using System.Net;
using System.Globalization;
using System.Threading;
using System.Xml.Linq;
using System.Xml.Schema;
using System.Xml.Serialization;

namespace SaleTransaction
{
    class Program
    {
        private static string ftpPathSalesTransaction = "ftp://192.168.0.75/QAS/210/Inbound/RTI001_SalesTransaction/";
        private static string ftpPathSalesTransactionEOD = "ftp://192.168.0.75/QAS/210/Inbound/RTI002_SalesTransactionEOD/";
        private static string ftpUsername = "sappo";
        private static string ftpPassword = "DohomeAtos";
        private static string ConnectionString = "server=192.168.0.106;database=dbmaster;user id=abc;password=abc;timeout=5;";
        private static MemoryStream stream;

        static void Main(string[] args)
        {
            for (var i = 0; i < 100; i++)
            {
                Thread.Sleep(10000);
                OnCreateXML_Cash("UB11");
            }
        }

        private static void OnCreateXML_Cash(string sSiteCode)
        {
            SqlConnection conn_sale = new SqlConnection();
            conn_sale.ConnectionString = ConnectionString;
            DataSet ds_sale = new DataSet();
            string sql_sale = "select * " +
                              "from dbtrans.dbo.tbtrans_pos_hd " +
                              "where exportflag = '0'" +
                              " and sitecode = '" + sSiteCode + "' " +
                              " and sysdocflag = '0'" +
                              " and doctype = '0'" +
                              " order by createdate desc";
            SqlDataAdapter da_sale = new SqlDataAdapter(sql_sale, conn_sale);
            da_sale.Fill(ds_sale);
            DataTable dt_header_salse = new DataTable();
            dt_header_salse = ds_sale.Tables[0];

            var doc_sale = new DT_RTI001_SALESTRANSACTION();
            if (dt_header_salse.Rows.Count > 0 && dt_header_salse != null)
            {
                doc_sale.POSDW_TRANSACTION_INT = new DT_RTI001_POSDW_TRANSACTION_INT[dt_header_salse.Rows.Count];

                for (int i = 0; i < dt_header_salse.Rows.Count; i++)
                {
                    DT_RTI001_POSDW_TRANSACTION_INT transactionInt = new DT_RTI001_POSDW_TRANSACTION_INT();

                    try
                    {
                        transactionInt.RETAILSTOREID = dt_header_salse.Rows[i]["SITECODE"].ToString();
                        transactionInt.BUSINESSDAYDATE = Convert_Date2(dt_header_salse.Rows[i]["DOCDATE"].ToString());
                        transactionInt.TRANSACTIONTYPECODE = "Z001";
                        transactionInt.WORKSTATIONID = dt_header_salse.Rows[i]["POSCODE"].ToString();
                        transactionInt.TRANSACTIONSEQUENCENUMBER = dt_header_salse.Rows[i]["DOCNO"].ToString();
                        transactionInt.BEGINDATETIMESTAMP = Convert_Date(dt_header_salse.Rows[i]["CREATEDATE"].ToString());
                        transactionInt.ENDDATETIMESTAMP = Convert_Date(dt_header_salse.Rows[i]["CREATEDATE"].ToString());
                        transactionInt.OPERATORID = dt_header_salse.Rows[i]["CASHIER"].ToString();
                        transactionInt.TRANSACTIONCURRENCY = "THB";

                        DataTable dt_detail = POS_DT(dt_header_salse.Rows[i]["DOCNO"].ToString(), dt_header_salse.Rows[i]["SITECODE"].ToString());
                        //RETAILLINEITEM NODE
                        transactionInt.RETAILLINEITEM = new DT_RTI001_POSDW_RETAILLINEITEM[dt_detail.Rows.Count];
                        for (int a = 0; a < dt_detail.Rows.Count; a++)
                        {
                            DT_RTI001_POSDW_RETAILLINEITEM retailLineItem = new DT_RTI001_POSDW_RETAILLINEITEM();

                            retailLineItem.RETAILSEQUENCENUMBER = (a + 1) + "";
                            retailLineItem.RETAILTYPECODE = "ZWSL";
                            retailLineItem.ITEMIDQUALIFIER = "2";
                            retailLineItem.ITEMID = dt_detail.Rows[a]["PRODUCTCODE"].ToString();
                            retailLineItem.RETAILQUANTITY = dt_detail.Rows[a]["quantity"].ToString();
                            retailLineItem.SALESUNITOFMEASURE = dt_detail.Rows[a]["UNITCODE"].ToString();
                            retailLineItem.SALESAMOUNT = dt_detail.Rows[a]["netamount"].ToString();
                            retailLineItem.NORMALSALESAMOUNT = dt_detail.Rows[a]["netamount"].ToString();
                            retailLineItem.COST = "0";
                            retailLineItem.ACTUALUNITPRICE = dt_detail.Rows[a]["UNITPRICE"].ToString();
                            retailLineItem.UNITS = "0";

                            retailLineItem.TAX = new DT_RTI001_POSDW_TAX[1];
                            DT_RTI001_POSDW_TAX taxRetailLineItem = new DT_RTI001_POSDW_TAX();
                            taxRetailLineItem.TAXSEQUENCENUMBER = "0001";
                            taxRetailLineItem.TAXTYPECODE = "1001";
                            taxRetailLineItem.TAXAMOUNT = dt_detail.Rows[a]["taxvalue"].ToString();
                            retailLineItem.TAX[0] = taxRetailLineItem;

                            transactionInt.RETAILLINEITEM[a] = retailLineItem;
                        }

                        int tender_cash = Convert.ToInt32(TENDERAMOUNT_data(dt_header_salse.Rows[i]["CASHAMOUNT"].ToString(), dt_header_salse.Rows[i]["CHANGEAMOUNT"].ToString()));

                        string sql_credit = "select * from dbtrans..TBTrans_Pos_Use_Creditcard where DOCNO ='" + dt_header_salse.Rows[i]["DOCNO"] + "'";
                        DataTable dt_tender_credit = new DataTable();
                        SqlDataAdapter da_credit = new SqlDataAdapter(sql_credit, conn_sale);
                        da_credit.Fill(dt_tender_credit);

                        if (tender_cash > 0)
                            transactionInt.TENDER = new DT_RTI001_POSDW_TENDER[dt_tender_credit.Rows.Count + 1];
                        else
                            transactionInt.TENDER = new DT_RTI001_POSDW_TENDER[dt_tender_credit.Rows.Count];

                        if (tender_cash > 0)
                        {
                            DT_RTI001_POSDW_TENDER tenderCash = new DT_RTI001_POSDW_TENDER();
                            tenderCash.TENDERSEQUENCENUMBER = "0";
                            tenderCash.TENDERTYPECODE = "CASH";
                            tenderCash.TENDERAMOUNT = tender_cash.ToString();
                            tenderCash.TENDERCURRENCY = "THB";
                            tenderCash.TENDERID = "0";

                            transactionInt.TENDER[0] = tenderCash;
                        }

                        for (int a = 0; a < dt_tender_credit.Rows.Count; a++)
                        {
                            DT_RTI001_POSDW_TENDER tender = new DT_RTI001_POSDW_TENDER();

                            // TENDERSEQUENCENUMBER if has tender_cash
                            if (tender_cash > 0)
                                tender.TENDERSEQUENCENUMBER = (a + 1).ToString();
                            else
                                tender.TENDERSEQUENCENUMBER = a.ToString();

                            tender.TENDERTYPECODE = "VISA";
                            tender.TENDERAMOUNT = dt_tender_credit.Rows[a]["CREDITTOTALAMOUNT"].ToString();
                            tender.TENDERCURRENCY = "THB";
                            tender.TENDERID = dt_tender_credit.Rows[a]["CREDITcARDNO"].ToString();

                            if (tender_cash > 0)
                                transactionInt.TENDER[a + 1] = tender;
                            else
                                transactionInt.TENDER[a] = tender;
                        }
                    }
                    catch (Exception ex)
                    {
                        Console.WriteLine(ex.ToString());
                    }

                    doc_sale.POSDW_TRANSACTION_INT[i] = transactionInt;
                }

                //Check folder temp ว่ามีหรือไม่ถ้าไม่มีให้สร้างก่อน
                //string sPathFileName = @"\Sales_" + sSiteCode + "_" + DateTime.Now.ToString("yyyyMMddHHmmss") + ".xml";

                // Create File
                //var serializer = new XmlSerializer(typeof(DT_RTI001_SALESTRANSACTION));
                //var xmlFilename = doCreateFileName(sSiteCode);
                //using (var stream = new StreamWriter(xmlFilename)) // -- doc_sale.Save(sPathFileName);
                //    serializer.Serialize(stream, doc_sale);

                // Stream File to FTP Process
                
                var sPathFileName = doCreateFileName(sSiteCode);
                using (stream = new MemoryStream())
                {
                    XmlSerializer serializer = new XmlSerializer(typeof(DT_RTI001_SALESTRANSACTION));
                    serializer.Serialize(
                        stream,
                        doc_sale
                    );

                    stream.Position = 0;

                    using (var reader = new StreamReader(stream, Encoding.UTF8))
                    {
                        if (StreamingXML2Ftp(reader, sPathFileName))
                        {
                            // Stream File Complete then verify
                        }
                    }
                }
                
            }
            else
            {
                Console.WriteLine("ไม่มีข้อมูล_sale");
            }
        }

        private static DataTable POS_DT(string DOCNO, string sitecode)
        {
            DataTable dt = new DataTable();
            SqlConnection conn = new SqlConnection();
            string sql = "select docno, docdate, sloc, productcode, unitcode, barcode, unitprice, salecolordocno, salecolorroworder " +
                        ", sum(quantity) as quantity, sum(taxvalue) as taxvalue, sum(netamount) as netamount " +
                " from dbtrans..tbtrans_pos_dt" +
                " where docno = '" + DOCNO + "'" +
                " group by docno, docdate, sloc, productcode, unitcode, barcode, unitprice, salecolordocno, salecolorroworder " +
                "";
            conn.ConnectionString = ConnectionString;
            SqlDataAdapter da = new SqlDataAdapter(sql, conn);
            da.Fill(dt);
            return dt;

        }

        private static string Convert_Date(string date)
        {
            DateTime datet = Convert.ToDateTime(date);
            return datet.ToString("yyyyMMddHHmmss", new CultureInfo("en-US"));
        }

        private static string Convert_Date2(string date)
        {
            DateTime datet = Convert.ToDateTime(date);
            return datet.ToString("yyyy-MM-dd", new CultureInfo("en-US"));
        }

        private static string TENDERAMOUNT_data(string cashamount, string changamount)
        {
            double casham = Convert.ToDouble(cashamount);
            double cashch = Convert.ToDouble(changamount);
            return (casham - cashch).ToString();
        }

        private static string doCreateFileName(string siteCode)
        {
            // begin generate filename
            string fileName = "Sales_" + siteCode;
            fileName += "_" + DateTime.Now.ToString("yyyyMMddHHmmss", new CultureInfo("en-US"));
            fileName += ".xml";

            return fileName;
        }

        /**
         * Stream File create on FTP 
         * */
        private static bool StreamingXML2Ftp(StreamReader sourceStream, string filename, int time = -1)
        {
            // Get the object used to communicate with the server.
            FtpWebRequest request = (FtpWebRequest)WebRequest.Create(ftpPathSalesTransaction + filename);
            request.Method = WebRequestMethods.Ftp.UploadFile;

            // This example assumes the FTP site uses anonymous logon.
            request.Credentials = new NetworkCredential(ftpUsername, ftpPassword);

            // Copy the contents of the file to the request stream.
            byte[] fileContents = Encoding.UTF8.GetBytes(sourceStream.ReadToEnd());
            request.ContentLength = fileContents.Length;

            Stream requestStream = request.GetRequestStream();
            requestStream.Write(fileContents, 0, fileContents.Length);
            requestStream.Close();

            FtpWebResponse response = (FtpWebResponse)request.GetResponse();
            Console.WriteLine("Upload File Complete, status {0}", response.StatusDescription);

            response.Close();

            if (time == -1)
                time = 3;

           if (ValidXMLSchema(filename))
            {
                sourceStream.Close();
                return true;
            }
            else
            {
                // If exists file then delete
                request = (FtpWebRequest)WebRequest.Create(ftpPathSalesTransaction + filename);
                request.Method = WebRequestMethods.Ftp.DeleteFile;
                request.Credentials = new NetworkCredential(ftpUsername, ftpPassword);
                response = (FtpWebResponse)request.GetResponse();
                response.Close();

                if (time > 0)
                {
                    time--;

                    stream.Position = 0;
                    using (var reader = new StreamReader(stream, Encoding.UTF8))
                    {
                        return StreamingXML2Ftp(reader, filename);
                    }
                }
                else
                {
                    return false;
                }
            }
        }

        /**
         * Check ความถูกต้อง XML
         * */
        private static bool ValidXMLSchema(string filename)
        {
            WebClient request = new WebClient();
            request.Credentials = new NetworkCredential(ftpUsername, ftpPassword);
            MemoryStream memory;

            try
            {
                memory = new MemoryStream();
                byte[] newFileData = request.DownloadData(new Uri(ftpPathSalesTransaction + filename));
                memory.Write(newFileData, 0, newFileData.Length);
                memory.Position = 0;
            }
            catch (WebException)
            {
                return false;
            }

            XmlSchemaSet schema = new XmlSchemaSet();
            schema.Add("https://dohome.co.th/POSOutbound/RT", "MT_RTI001_SALESTRANSACTION.xsd");

            try
            {
                XmlReader rd = XmlReader.Create(memory);
                XDocument xdoc = XDocument.Load(rd);
                bool isValid = true;
                xdoc.Validate(schema, (s, args) =>
                {
                    isValid = false;
                    if (args.Severity == XmlSeverityType.Warning)

                        Console.WriteLine("\tWarning: " + args.Message);
                    else
                        Console.WriteLine("\tError: " + args.Message);
                });

                if (isValid)
                    return true;
                else
                    return false;

            }
            catch (Exception)
            {
                return false;
            }
        }

    }
}
